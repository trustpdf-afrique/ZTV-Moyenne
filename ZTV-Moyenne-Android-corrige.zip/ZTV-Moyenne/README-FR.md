# ZTV-Moyenne

Application Android basée sur le site :

https://trustpdf-afrique.github.io/Calcul-moyenne/?app=eleve

## Ce projet contient
- le nom d'application : ZTV-Moyenne
- le logo fourni
- une interface Android WebView
- JavaScript et stockage local activés
- navigation Android avec le bouton Retour
- aucune dépendance à un abonnement mensuel

## Créer l'APK
Ouvre ce projet dans Android Studio, puis :
1. Attends la synchronisation Gradle.
2. Va dans **Build > Build APK(s)**.
3. L'APK de test sera généré dans `app/build/outputs/apk/`.

## Important
L'application charge le site en ligne. Elle nécessite donc une connexion Internet pour accéder au site.
