# ZTV Moyenne

Application Android hors-ligne basée sur l’application HTML existante.

- Nom Android : **ZTV Moyenne**
- Identifiant : `com.ztv.moyenne`
- Page web locale : `www/index.html`
- Logo : `resources/icon.png`
- Construction automatique de l’APK avec GitHub Actions.

## Utilisation sur GitHub

1. Créez un dépôt GitHub.
2. Envoyez tous les fichiers de ce dossier dans le dépôt.
3. Ouvrez l’onglet **Actions**.
4. Lancez **Construire APK ZTV Moyenne**.
5. Téléchargez l’APK dans la section **Artifacts**.

L’application fonctionne localement sans Internet. Le bouton WhatsApp nécessite une connexion Internet pour ouvrir/utiliser WhatsApp.
