@echo off
setlocal
set "GRADLE_VERSION=8.10.2"
set "DIST=%USERPROFILE%\.gradle\ztv-wrapper\gradle-%GRADLE_VERSION%"
if not exist "%DIST%\bin\gradle.bat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $d='%USERPROFILE%\.gradle\ztv-wrapper'; New-Item -ItemType Directory -Force $d | Out-Null; Invoke-WebRequest $u -OutFile ($d+'\gradle.zip'); Expand-Archive -Force ($d+'\gradle.zip') $d"
)
call "%DIST%\bin\gradle.bat" %*
