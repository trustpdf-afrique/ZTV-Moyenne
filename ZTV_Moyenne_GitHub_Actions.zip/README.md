# ZTV Moyenne — Android + GitHub Actions

Ce projet transforme le site ZTV Moyenne en application Android WebView et contient déjà
un workflow GitHub Actions pour compiler automatiquement l'APK.

## 1. Créer le dépôt GitHub

Sur GitHub, crée un nouveau dépôt, par exemple `ZTV-Moyenne-Android`.

Ensuite, envoie **tout le contenu de ce dossier** dans le dépôt, notamment :
- `app/`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`
- `gradlew`
- `gradlew.bat`
- `.github/workflows/build-apk.yml`

## 2. Lancer la compilation

Après l'envoi sur GitHub :

**Actions → Build ZTV Moyenne APK → Run workflow**

Le workflow peut aussi démarrer automatiquement lorsqu'un commit est envoyé sur `main`.

## 3. Récupérer l'APK

Quand l'exécution est terminée :
**Actions → Build ZTV Moyenne APK → dernière exécution → Artifacts → ZTV-Moyenne-APK**

Télécharge l'artifact ZIP puis récupère `app-debug.apk`.

## Important

L'APK charge le site en ligne :
https://trustpdf-afrique.github.io/Bonne-application-de-calcul-moyenne-/

Il faut donc une connexion Internet pour charger le site.

Cette configuration utilise GitHub Actions et ne nécessite pas d'abonnement mensuel à un service de conversion.
